# Modern Blog Platform

A full-stack blogging platform built with React, TypeScript, and Supabase.

## Features

- User authentication (register, login, logout)
- Create, read, update, and delete blog posts
- Comment system
- User profiles
- Responsive design
- Real-time updates

## Tech Stack

- Frontend:
  - React
  - TypeScript
  - Tailwind CSS
  - React Router
  - Lucide React (icons)
  - date-fns (date formatting)

- Backend:
  - Supabase (Database & Authentication)

## Setup Instructions

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a Supabase project and get your project URL and anon key

4. Create a `.env` file in the root directory with your Supabase credentials:
   ```
   VITE_SUPABASE_URL=your_supabase_project_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

5. Run the development server:
   ```bash
   npm run dev
   ```

## Database Schema

The application uses the following tables:

- `profiles`: User profiles
- `posts`: Blog posts
- `comments`: Post comments

## Deployment

1. Build the project:
   ```bash
   npm run build
   ```

2. Deploy the `dist` folder to your preferred hosting service

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request